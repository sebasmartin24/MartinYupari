function validar() {
  let nombre = document.getElementById("nombre");
  let email = document.getElementById("email");


  nombre.classList.remove("error");
  email.classList.remove("error");

  if (nombre.value.trim() === "") nombre.classList.add("error");
  if (email.value.trim() === "") email.classList.add("error");

  if (nombre.value && email.value) {
    alert("Formulario enviado ");
  } else {
    alert("Completa todos los campos.");
  }
}


let oscuro = false;
function cambiarTema() {
  const link = document.getElementById("tema");
  const boton = document.getElementById("temaBtn");
  oscuro = !oscuro;

  if (oscuro) {
    link.href = "tema_oscuro.css";
    boton.style.backgroundColor = "#333";
    boton.textContent = "Cambiar a tema claro";
  } else {
    link.href = "style.css";
    boton.style.backgroundColor = "orange";
    boton.textContent = "Cambiar a tema oscuro";
  }
}
