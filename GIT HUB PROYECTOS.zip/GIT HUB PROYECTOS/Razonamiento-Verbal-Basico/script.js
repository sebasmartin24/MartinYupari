let score = 0;
let currentSection = '';
let currentQuestion = 0;

// Función de audio (solo para respuestas correctas)
function playSound(correct) {
    if ('speechSynthesis' in window && correct) {
        const utterance = new SpeechSynthesisUtterance('¡Excelente!');
        utterance.lang = 'es-ES';
        utterance.rate = 1;
        utterance.pitch = 1.5;
        speechSynthesis.speak(utterance);
    }
}

// Iniciar
function startApp() {
    document.querySelector('.hero').style.display = 'none';
    document.querySelector('.menu-principal').style.display = 'grid';
}

// Ir a sección
function goToSection(section) {
    currentSection = section;
    currentQuestion = 0;
    document.querySelector('.menu-principal').style.display = 'none';
    document.querySelectorAll('.section-content').forEach(s => {
        s.classList.remove('active');
    });
    document.getElementById(section).classList.add('active');
    
    switch(section) {
        case 'sinonimos': loadSinonimos(); break;
        case 'antonimos': loadAntonimos(); break;
        case 'analogias': loadAnalogias(); break;
        case 'oraciones': loadOraciones(); break;
        case 'series': loadSeries(); break;
        case 'categorias': loadCategorias(); break;
    }
}

// Volver
function goBack() {
    document.querySelectorAll('.section-content').forEach(s => {
        s.classList.remove('active');
    });
    document.querySelector('.menu-principal').style.display = 'grid';
}

// Actualizar puntuación
function updateScore(points) {
    score += points;
    document.getElementById('scoreDisplay').textContent = score;
}

// ============ SINÓNIMOS ============
const sinonimosData = [
    { palabra: 'FELIZ', opciones: ['CONTENTO', 'TRISTE', 'ENOJADO', 'DORMIDO'], correcta: 0 },
    { palabra: 'GRANDE', opciones: ['PEQUEÑO', 'ENORME', 'BAJO', 'DELGADO'], correcta: 1 },
    { palabra: 'RÁPIDO', opciones: ['LENTO', 'VELOZ', 'QUIETO', 'PESADO'], correcta: 1 },
    { palabra: 'BONITO', opciones: ['FEO', 'HERMOSO', 'SUCIO', 'VIEJO'], correcta: 1 },
    { palabra: 'INTELIGENTE', opciones: ['TONTO', 'LISTO', 'LOCO', 'MALO'], correcta: 1 },
    { palabra: 'COMENZAR', opciones: ['TERMINAR', 'INICIAR', 'PARAR', 'DORMIR'], correcta: 1 },
    { palabra: 'VALIENTE', opciones: ['COBARDE', 'MIEDOSO', 'DÉBIL', 'AUDAZ'], correcta: 3 },
    { palabra: 'DIFÍCIL', opciones: ['FÁCIL', 'SIMPLE', 'COMPLICADO', 'LIGERO'], correcta: 2 }
];

function loadSinonimos() {
    if (currentQuestion >= sinonimosData.length) {
        showCompletion('sinonimo');
        return;
    }
    
    const data = sinonimosData[currentQuestion];
    document.getElementById('sinonimoQuestion').textContent = `¿Qué significa lo mismo que "${data.palabra}"?`;
    document.getElementById('sinonimoFeedback').classList.remove('show');
    
    const optionsContainer = document.getElementById('sinonimoOptions');
    optionsContainer.innerHTML = '';
    
    data.opciones.forEach((opcion, index) => {
        const btn = document.createElement('button');
        btn.className = 'option-btn';
        btn.textContent = opcion;
        btn.onclick = () => checkAnswer('sinonimo', index, data.correcta);
        optionsContainer.appendChild(btn);
    });
}

// ============ ANTÓNIMOS ============
const antonimosData = [
    { palabra: 'ALTO', opciones: ['BAJO', 'GRANDE', 'GORDO', 'ANCHO'], correcta: 0 },
    { palabra: 'CALIENTE', opciones: ['TIBIO', 'FRÍO', 'SECO', 'HÚMEDO'], correcta: 1 },
    { palabra: 'LIMPIO', opciones: ['PURO', 'CLARO', 'SUCIO', 'BLANCO'], correcta: 2 },
    { palabra: 'NUEVO', opciones: ['MODERNO', 'RECIENTE', 'VIEJO', 'BONITO'], correcta: 2 },
    { palabra: 'CERCA', opciones: ['JUNTO', 'LEJOS', 'AQUÍ', 'LADO'], correcta: 1 },
    { palabra: 'DÍA', opciones: ['SOL', 'NOCHE', 'TARDE', 'MAÑANA'], correcta: 1 },
    { palabra: 'SUBIR', opciones: ['BAJAR', 'SALTAR', 'CORRER', 'VOLAR'], correcta: 0 },
    { palabra: 'LLENO', opciones: ['COMPLETO', 'VACÍO', 'GORDO', 'PESADO'], correcta: 1 }
];

function loadAntonimos() {
    if (currentQuestion >= antonimosData.length) {
        showCompletion('antonimo');
        return;
    }
    
    const data = antonimosData[currentQuestion];
    document.getElementById('antonimoQuestion').textContent = `¿Qué significa lo CONTRARIO de "${data.palabra}"?`;
    document.getElementById('antonimoFeedback').classList.remove('show');
    
    const optionsContainer = document.getElementById('antonimoOptions');
    optionsContainer.innerHTML = '';
    
    data.opciones.forEach((opcion, index) => {
        const btn = document.createElement('button');
        btn.className = 'option-btn';
        btn.textContent = opcion;
        btn.onclick = () => checkAnswer('antonimo', index, data.correcta);
        optionsContainer.appendChild(btn);
    });
}

// ============ ANALOGÍAS ============
const analogiasData = [
    { pregunta: 'PERRO es a CACHORRO como GATO es a...', opciones: ['MASCOTA', 'GATITO', 'FELINO', 'ANIMAL'], correcta: 1 },
    { pregunta: 'DÍA es a SOL como NOCHE es a...', opciones: ['ESTRELLA', 'LUNA', 'OSCURO', 'DORMIR'], correcta: 1 },
    { pregunta: 'MANO es a GUANTE como PIE es a...', opciones: ['CALCETÍN', 'ZAPATO', 'PIERNA', 'DEDO'], correcta: 1 },
    { pregunta: 'LIBRO es a LEER como MÚSICA es a...', opciones: ['CANTAR', 'ESCUCHAR', 'BAILAR', 'TOCAR'], correcta: 1 },
    { pregunta: 'MAESTRO es a ESCUELA como DOCTOR es a...', opciones: ['MEDICINA', 'HOSPITAL', 'CURAR', 'ENFERMERA'], correcta: 1 },
    { pregunta: 'PÁJARO es a VOLAR como PEZ es a...', opciones: ['AGUA', 'NADAR', 'MAR', 'ESCAMAS'], correcta: 1 },
    { pregunta: 'OJO es a VER como NARIZ es a...', opciones: ['RESPIRAR', 'OLER', 'CARA', 'SOPLAR'], correcta: 1 },
    { pregunta: 'VERANO es a CALOR como INVIERNO es a...', opciones: ['NIEVE', 'FRÍO', 'HIELO', 'NAVIDAD'], correcta: 1 }
];

function loadAnalogias() {
    if (currentQuestion >= analogiasData.length) {
        showCompletion('analogia');
        return;
    }
    
    const data = analogiasData[currentQuestion];
    document.getElementById('analogiaQuestion').textContent = data.pregunta;
    document.getElementById('analogiaFeedback').classList.remove('show');
    
    const optionsContainer = document.getElementById('analogiaOptions');
    optionsContainer.innerHTML = '';
    
    data.opciones.forEach((opcion, index) => {
        const btn = document.createElement('button');
        btn.className = 'option-btn';
        btn.textContent = opcion;
        btn.onclick = () => checkAnswer('analogia', index, data.correcta);
        optionsContainer.appendChild(btn);
    });
}

// ============ ORACIONES ============
const oracionesData = [
    { oracion: 'El león es el ___ de la selva', opciones: ['ANIMAL', 'REY', 'GATO', 'GRANDE'], correcta: 1 },
    { oracion: 'Las ___ vuelan en el cielo', opciones: ['NUBES', 'AVES', 'HOJAS', 'AVIONES'], correcta: 1 },
    { oracion: 'En el ___ nadamos y nos refrescamos', opciones: ['RÍO', 'MAR', 'AGUA', 'PISCINA'], correcta: 2 },
    { oracion: 'La ___ sale de noche y brilla', opciones: ['LUNA', 'ESTRELLA', 'LUZ', 'NOCHE'], correcta: 0 },
    { oracion: 'Los ___ crecen en el jardín', opciones: ['PLANTAS', 'FLORES', 'ÁRBOLES', 'TODOS'], correcta: 1 },
    { oracion: 'Uso el ___ para escribir', opciones: ['PAPEL', 'CUADERNO', 'LÁPIZ', 'LIBRO'], correcta: 2 },
    { oracion: 'El ___ nos da luz y calor', opciones: ['FUEGO', 'SOL', 'FOCO', 'VERANO'], correcta: 1 },
    { oracion: 'Cuando llueve uso el ___', opciones: ['ABRIGO', 'PARAGUAS', 'SOMBRERO', 'IMPERMEABLE'], correcta: 1 }
];

function loadOraciones() {
    if (currentQuestion >= oracionesData.length) {
        showCompletion('oracion');
        return;
    }
    
    const data = oracionesData[currentQuestion];
    document.getElementById('oracionQuestion').textContent = data.oracion;
    document.getElementById('oracionFeedback').classList.remove('show');
    
    const optionsContainer = document.getElementById('oracionOptions');
    optionsContainer.innerHTML = '';
    
    data.opciones.forEach((opcion, index) => {
        const btn = document.createElement('button');
        btn.className = 'option-btn';
        btn.textContent = opcion;
        btn.onclick = () => checkAnswer('oracion', index, data.correcta);
        optionsContainer.appendChild(btn);
    });
}

// ============ SERIES VERBALES ============
const seriesData = [
    { serie: 'LUNES - MARTES - MIÉRCOLES - ?', opciones: ['VIERNES', 'JUEVES', 'SÁBADO', 'DOMINGO'], correcta: 1 },
    { serie: 'PRIMAVERA - VERANO - OTOÑO - ?', opciones: ['INVIERNO', 'CLIMA', 'AÑO', 'LLUVIA'], correcta: 0 },
    { serie: 'GATO - PERRO - CONEJO - ?', opciones: ['ANIMAL', 'LEÓN', 'CABALLO', 'TODOS'], correcta: 2 },
    { serie: 'ROJO - AZUL - VERDE - ?', opciones: ['AMARILLO', 'COLOR', 'PINTURA', 'MORADO'], correcta: 0 },
    { serie: 'ENERO - FEBRERO - MARZO - ?', opciones: ['JUNIO', 'MAYO', 'ABRIL', 'JULIO'], correcta: 2 },
    { serie: 'MANZANA - PLÁTANO - NARANJA - ?', opciones: ['FRUTA', 'UVA', 'COMIDA', 'JUGO'], correcta: 1 },
    { serie: 'NIÑO - JOVEN - ADULTO - ?', opciones: ['ANCIANO', 'VIEJO', 'MAYOR', 'ABUELO'], correcta: 0 },
    { serie: 'DESAYUNO - ALMUERZO - MERIENDA - ?', opciones: ['NOCHE', 'COMIDA', 'CENA', 'DORMIR'], correcta: 2 }
];

function loadSeries() {
    if (currentQuestion >= seriesData.length) {
        showCompletion('serie');
        return;
    }
    
    const data = seriesData[currentQuestion];
    document.getElementById('serieQuestion').textContent = data.serie;
    document.getElementById('serieFeedback').classList.remove('show');
    
    const optionsContainer = document.getElementById('serieOptions');
    optionsContainer.innerHTML = '';
    
    data.opciones.forEach((opcion, index) => {
        const btn = document.createElement('button');
        btn.className = 'option-btn';
        btn.textContent = opcion;
        btn.onclick = () => checkAnswer('serie', index, data.correcta);
        optionsContainer.appendChild(btn);
    });
}

// ============ CATEGORÍAS ============
const categoriasData = [
    { pregunta: '¿Cuál NO es una fruta?', opciones: ['MANZANA', 'ZANAHORIA', 'PERA', 'UVA'], correcta: 1 },
    { pregunta: '¿Cuál NO es un animal?', opciones: ['PERRO', 'GATO', 'ÁRBOL', 'LEÓN'], correcta: 2 },
    { pregunta: '¿Cuál NO es un color?', opciones: ['ROJO', 'AZUL', 'MESA', 'VERDE'], correcta: 2 },
    { pregunta: '¿Cuál NO es transporte?', opciones: ['CARRO', 'AVIÓN', 'SILLA', 'BARCO'], correcta: 2 },
    { pregunta: '¿Cuál NO es ropa?', opciones: ['CAMISA', 'PANTALÓN', 'ZAPATO', 'LIBRO'], correcta: 3 },
    { pregunta: '¿Cuál NO se come?', opciones: ['PAN', 'ARROZ', 'PIEDRA', 'CARNE'], correcta: 2 },
    { pregunta: '¿Cuál NO está en la casa?', opciones: ['CAMA', 'MESA', 'NUBE', 'SILLA'], correcta: 2 },
    { pregunta: '¿Cuál NO es parte del cuerpo?', opciones: ['MANO', 'PIE', 'OJO', 'ÁRBOL'], correcta: 3 }
];

function loadCategorias() {
    if (currentQuestion >= categoriasData.length) {
        showCompletion('categoria');
        return;
    }
    
    const data = categoriasData[currentQuestion];
    document.getElementById('categoriaQuestion').textContent = data.pregunta;
    document.getElementById('categoriaFeedback').classList.remove('show');
    
    const optionsContainer = document.getElementById('categoriaOptions');
    optionsContainer.innerHTML = '';
    
    data.opciones.forEach((opcion, index) => {
        const btn = document.createElement('button');
        btn.className = 'option-btn';
        btn.textContent = opcion;
        btn.onclick = () => checkAnswer('categoria', index, data.correcta);
        optionsContainer.appendChild(btn);
    });
}

// ============ VERIFICAR RESPUESTA ============
function checkAnswer(tipo, selected, correct) {
    const buttons = document.querySelectorAll(`#${tipo}Options .option-btn`);
    const feedback = document.getElementById(`${tipo}Feedback`);
    
    buttons.forEach(btn => btn.disabled = true);
    
    if (selected === correct) {
        buttons[selected].classList.add('correct');
        feedback.className = 'feedback correct show';
        feedback.textContent = '🎉 ¡EXCELENTE!';
        playSound(true);
        updateScore(10);
        
        setTimeout(() => {
            currentQuestion++;
            switch(tipo) {
                case 'sinonimo': loadSinonimos(); break;
                case 'antonimo': loadAntonimos(); break;
                case 'analogia': loadAnalogias(); break;
                case 'oracion': loadOraciones(); break;
                case 'serie': loadSeries(); break;
                case 'categoria': loadCategorias(); break;
            }
        }, 2000);
    } else {
        buttons[selected].classList.add('wrong');
        buttons[correct].classList.add('correct');
        feedback.className = 'feedback wrong show';
        feedback.textContent = '❌ Intenta otra vez';
        
        setTimeout(() => {
            currentQuestion++;
            switch(tipo) {
                case 'sinonimo': loadSinonimos(); break;
                case 'antonimo': loadAntonimos(); break;
                case 'analogia': loadAnalogias(); break;
                case 'oracion': loadOraciones(); break;
                case 'serie': loadSeries(); break;
                case 'categoria': loadCategorias(); break;
            }
        }, 2500);
    }
}

// ============ MOSTRAR COMPLETADO ============
function showCompletion(tipo) {
    const questionBox = document.getElementById(`${tipo}Question`);
    const optionsContainer = document.getElementById(`${tipo}Options`);
    const feedback = document.getElementById(`${tipo}Feedback`);
    
    questionBox.innerHTML = '🏆 ¡COMPLETASTE TODO!';
    optionsContainer.innerHTML = '';
    feedback.className = 'feedback correct show';
    feedback.innerHTML = `
        ✨ ¡Muy bien! ✨<br>
        <button class="btn-start" style="font-size: 1.5em; padding: 20px 40px; margin-top: 20px;" onclick="goBack()">
            🔙 VOLVER AL MENÚ
        </button>
    `;
    
    if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance('¡Felicidades! Completaste todos los ejercicios');
        utterance.lang = 'es-ES';
        utterance.rate = 0.9;
        speechSynthesis.speak(utterance);
    }
}