document.addEventListener('DOMContentLoaded', () => {
    
    // 1. Configuración de la Animación
    const rows = document.querySelectorAll('.gallery-row');
    
    // 🔥 AJUSTE DE VELOCIDAD: Lo incrementamos a 1.0
    const scrollSpeed = 1.0; 
    
    // Cálculo del ancho total de desplazamiento (el ancho de la galería original)
    // 6 imágenes * 250px (ancho) + 6 imágenes * 10px (margen_derecho) = 1560px
    const imageWidth = 250;
    const imageMargin = 10;
    const numImagesOriginal = 6;
    const scrollWidth = (imageWidth + imageMargin) * numImagesOriginal; // 1560

    // Almacena la posición inicial y actual de cada fila
    let currentPositions = new Map();
    
    // 2. Inicialización de Posiciones y Direcciones
    rows.forEach((row, index) => {
        
        // Asignamos un ID si no lo tienen
        row.id = row.id || `carrusel-${index + 1}`; 
        
        let initialPosition;
        let isMovingLeft;
        
        // Lógica de dirección: Fila 1 a la derecha, resto a la izquierda
        if (index === 0) {
            // Fila 1: Derecha (debe empezar en -scrollWidth)
            isMovingLeft = false;
            initialPosition = -scrollWidth;
        } else {
            // Fila 2 y 3: Izquierda (debe empezar en 0)
            isMovingLeft = true;
            initialPosition = 0;
        }
        
        // Guardamos la posición inicial
        currentPositions.set(row.id, initialPosition);
        
        // Añadimos una propiedad de datos para que la función de animación sepa la dirección
        row.dataset.moveLeft = isMovingLeft;
    });


    /**
     * Función principal para mover las filas usando requestAnimationFrame.
     */
    function animateScroll() {
        rows.forEach(row => {
            const rowId = row.id;
            let currentX = currentPositions.get(rowId);
            
            // Leemos la dirección del atributo de datos
            const isMovingLeft = row.dataset.moveLeft === 'true'; 

            if (isMovingLeft) {
                // Mueve a la izquierda: resta la velocidad
                currentX -= scrollSpeed;
                
                // Bucle de reinicio
                if (currentX <= -scrollWidth) {
                    currentX += scrollWidth; 
                }
            } else {
                // Mueve a la derecha: suma la velocidad
                currentX += scrollSpeed;
                
                // Bucle de reinicio
                if (currentX >= 0) {
                    currentX -= scrollWidth;
                }
            }

            // Aplica la nueva posición al estilo
            row.style.transform = `translateX(${currentX}px)`;
            
            // Actualiza la posición en el mapa
            currentPositions.set(rowId, currentX);
        });

        requestAnimationFrame(animateScroll);
    }
    
    // 3. Inicia la animación
    animateScroll();

    /* ----------------------------------------------------
       BONUS: Pausar en Hover
       ---------------------------------------------------- */
    rows.forEach(row => {
        row.addEventListener('mouseenter', () => {
            row.style.animationPlayState = 'paused'; 
            row.style.cursor = 'grab';
        });
        row.addEventListener('mouseleave', () => {
            row.style.animationPlayState = 'running';
        });
    });

});