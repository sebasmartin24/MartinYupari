Proyecto completado por: Martín Yupari Sebastián
Curso: Diseño Web
Actividad: Evolución de HTML - Páginas de muestra y capturas
Fecha: 2/11/2025


Proyecto: Evolución de HTML - páginas de muestra
Archivos incluidos:
- html1.html       -> Ejemplo HTML 1.0 (básico)
- html2.html       -> Ejemplo HTML 2.0 (formularios)
- html3_2.html     -> Ejemplo HTML 3.2 (tablas y font)
- html4_01.html    -> Ejemplo HTML 4.01 + css/style-html4.css
- html5.html       -> Ejemplo HTML5 (audio, video, canvas)
- html5-assets/    -> carpeta para colocar sample.mp3 y sample.mp4 (opcionales)
- living.html      -> Ejemplo Living Standard (localStorage, contentEditable)

Cómo probar:
1. Abrir cada archivo .html en el navegador (doble clic o arrastrar al navegador).
2. Para html5.html, coloca sample.mp3 y sample.mp4 en html5-assets/ o quita las etiquetas multimedia.
3. Tomar capturas de pantalla de cada página y pegarlas en un documento de Google.
4. Comprimir la carpeta en un ZIP y subirlo a la plataforma.

Capturas de pantalla:
Las capturas de cada versión están guardadas en la carpeta /capturas
- html1.png → Página básica (texto y enlaces simples)
- html2.png → Formularios iniciales
- html3.png → Uso de tablas y etiqueta <font>
- html4.png → Ejemplo con CSS externo
- html5.png → Etiquetas multimedia (audio, video, canvas)
- living-standar.png → Ejemplo con APIs modernas (localStorage, contentEditable)


Nota:
Cada página representa visualmente la evolución del lenguaje HTML desde 1993 hasta la actualidad.
Los ejemplos incluyen características propias de cada versión (formularios, estilos, multimedia y APIs modernas).

