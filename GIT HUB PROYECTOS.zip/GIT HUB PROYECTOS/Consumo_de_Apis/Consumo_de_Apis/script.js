// Navegación entre secciones
document.querySelectorAll('.nav-btn').forEach(button => {
    button.addEventListener('click', () => {
        // Remover clase active de todos los botones y secciones
        document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.content-section').forEach(section => section.classList.remove('active'));
        
        // Agregar clase active al botón clickeado
        button.classList.add('active');
        
        // Mostrar la sección correspondiente
        const sectionId = button.getAttribute('data-section');
        document.getElementById(sectionId).classList.add('active');
    });
});

// Base de datos completa de películas CORREGIDA
const allMovies = [
    { 
        title: "Avengers: Endgame", 
        overview: "Los Vengadores restantes deben encontrar una manera de recuperar a sus aliados para un enfrentamiento épico con Thanos.", 
        poster: "https://image.tmdb.org/t/p/w500/or06FN3Dka5tukK1e9sl16pB3iy.jpg",
        keywords: ["avengers", "vengadores", "marvel", "superhéroes", "thanos", "endgame"],
        url: "https://www.imdb.com/title/tt4154796/"
    },
    { 
        title: "Avengers: Infinity War", 
        overview: "Los Vengadores y sus aliados deben estar dispuestos a sacrificarlo todo para intentar derrotar al poderoso Thanos.", 
        poster: "https://image.tmdb.org/t/p/w500/7WsyChQLEftFiDOVTGkv3hFpyyt.jpg",
        keywords: ["avengers", "vengadores", "marvel", "thanos", "infinity", "war"],
        url: "https://www.imdb.com/title/tt4154756/"
    },
    { 
        title: "Spider-Man: No Way Home", 
        overview: "Peter Parker es desenmascarado y ya no puede separar su vida normal de los altos riesgos de ser un superhéroe.", 
        poster: "https://image.tmdb.org/t/p/w500/5a7lMDn3nAj2ByO0X1fg6BhUphR.jpg",
        keywords: ["spider", "spiderman", "hombre araña", "marvel", "peter parker", "no way home"],
        url: "https://www.imdb.com/title/tt10872600/"
    },
    { 
        title: "The Batman", 
        overview: "Batman explora la corrupción existente en la ciudad de Gotham y el vínculo de esta con su propia familia.", 
        poster: "https://image.tmdb.org/t/p/w500/5P8SmMzSNYikXpxil6BYzJ16611.jpg",
        keywords: ["batman", "dc", "superhéroe", "gotham", "robert pattinson"],
        url: "https://www.imdb.com/title/tt1877830/"
    },
    { 
        title: "Dune", 
        overview: "Paul Atreides debe viajar al planeta más peligroso del universo para asegurar el futuro de su familia y su pueblo.", 
        poster: "https://image.tmdb.org/t/p/w500/d5NXSklXo0qyIYkgV94XAgMIckC.jpg",
        keywords: ["dune", "ciencia ficción", "aventura", "espacio", "timothée chalamet"],
        url: "https://www.imdb.com/title/tt1160419/"
    },
    { 
        title: "Black Panther: Wakanda Forever", 
        overview: "El pueblo de Wakanda lucha para embarcarse en un nuevo capítulo tras la muerte del Rey T'Challa.", 
        poster: "https://image.tmdb.org/t/p/w500/sv1xJUazXeYqALzczSZ3O6nkH75.jpg",
        keywords: ["black panther", "pantera negra", "marvel", "wakanda", "chadwick boseman"],
        url: "https://www.imdb.com/title/tt9114286/"
    },
    { 
        title: "Top Gun: Maverick", 
        overview: "Maverick, quien lleva más de 30 años de servicio, es ahora instructor de pilotos.", 
        poster: "https://image.tmdb.org/t/p/w500/62HCnUTziyWcpDaBO2i1DX17ljH.jpg",
        keywords: ["top gun", "maverick", "avión", "acción", "tom cruise"],
        url: "https://www.imdb.com/title/tt1745960/"
    },
    { 
        title: "Avatar: The Way of Water", 
        overview: "Jake Sully y Ney'tiri han formado una familia y hacen todo lo posible por permanecer juntos.", 
        poster: "https://image.tmdb.org/t/p/w500/t6HIqrRAclMCA60NsSmeqe9RmNV.jpg",
        keywords: ["avatar", "ciencia ficción", "aventura", "pandora", "james cameron"],
        url: "https://www.imdb.com/title/tt1630029/"
    },
    { 
        title: "John Wick 4", 
        overview: "John Wick descubre un camino para derrotar a la Alta Mesa. Pero para ganar su libertad, deberá enfrentar a un nuevo enemigo.", 
        poster: "https://image.tmdb.org/t/p/w500/vZloFAK7NmvMGKE7VkF5UHaz0I.jpg",
        keywords: ["john wick", "acción", "keanu reeves", "alta mesa"],
        url: "https://www.imdb.com/title/tt10366206/"
    },
    { 
        title: "Guardians of the Galaxy Vol. 3", 
        overview: "Peter Quill debe reunir a su equipo para defender el universo y proteger a uno de los suyos.", 
        poster: "https://image.tmdb.org/t/p/w500/nAbpLidFdbbi3efFQKMPQJkaZ1r.jpg",
        keywords: ["guardians", "galaxy", "marvel", "guardianes", "rocket"],
        url: "https://www.imdb.com/title/tt6791350/"
    },
    { 
        title: "The Super Mario Bros. Movie", 
        overview: "Un fontanero llamado Mario viaja a través de una tubería hasta un mundo mágico con su hermano Luigi.", 
        poster: "https://image.tmdb.org/t/p/w500/qNBAXBIQlnOThrVvA6mA2B5ggV6.jpg",
        keywords: ["mario", "nintendo", "animación", "aventura", "chris pratt"],
        url: "https://www.imdb.com/title/tt6718170/"
    },
    { 
        title: "Fast & Furious 10", 
        overview: "Dom Toretto y su familia se enfrentan a su oponente más letal hasta el momento.", 
        poster: "https://image.tmdb.org/t/p/w500/fiVW06jE7z9YnO4trhaMEdclSiC.jpg",
        keywords: ["fast", "furious", "coches", "acción", "vin diesel"],
        url: "https://www.imdb.com/title/tt5433140/"
    },
    { 
        title: "The Flash", 
        overview: "Barry Allen viaja atrás en el tiempo para evitar el asesinato de su madre, lo que atrapa a sus compañeros superhéroes en una realidad alternativa.", 
        poster: "https://image.tmdb.org/t/p/w500/rktDFPbfHfUbArZ6OOOKsXcv0Bm.jpg",
        keywords: ["flash", "dc", "superhéroe", "velocidad", "ezra miller"],
        url: "https://www.imdb.com/title/tt0439572/"
    },
    { 
        title: "Transformers: El despertar de las bestias", 
        overview: "Los Autobots se enfrentan a una nueva amenaza terrorífica que llega a la Tierra.", 
        poster: "https://image.tmdb.org/t/p/w500/gPbM0MK8CP8A174rmUwGsADNYKD.jpg",
        keywords: ["transformers", "autobots", "acción", "robots", "optimus prime", "bestias"],
        url: "https://www.imdb.com/title/tt5090568/"
    },
    { 
        title: "Mission: Impossible - Dead Reckoning", 
        overview: "Ethan Hunt y su equipo del IMF se embarcan en su misión más peligrosa hasta la fecha.", 
        poster: "https://image.tmdb.org/t/p/w500/NNxYkU70HPurnNCSiCjYAmacwm.jpg",
        keywords: ["mission impossible", "tom cruise", "acción", "espionaje", "ethan hunt"],
        url: "https://www.imdb.com/title/tt9603212/"
    },
    { 
        title: "Barbie", 
        overview: "Barbie vive en Barbie Land, pero después de experimentar una crisis existencial, viaja al mundo humano para encontrar la verdadera felicidad.", 
        poster: "https://image.tmdb.org/t/p/w500/nHf61UzkfFno5X1ofIhugCPus2R.jpg",
        keywords: ["barbie", "comedia", "aventura", "margot robbie", "fantasía"],
        url: "https://www.imdb.com/title/tt1517268/"
    }
];

// Películas - Búsqueda MEJORADA y más flexible
document.getElementById('search-movie').addEventListener('click', () => {
    const searchTerm = document.getElementById('movie-input').value.toLowerCase().trim();
    const moviesData = document.getElementById('movies-data');
    
    let filteredMovies;
    
    if (searchTerm === '') {
        // Si no hay término de búsqueda, mostrar todas las películas
        filteredMovies = allMovies;
    } else {
        // Búsqueda INTELIGENTE mejorada que busca en título y keywords
        filteredMovies = allMovies.filter(movie => {
            const searchWords = searchTerm.split(' ');
            
            // Buscar en el título
            const titleMatch = movie.title.toLowerCase().includes(searchTerm);
            
            // Buscar en keywords
            const keywordMatch = movie.keywords.some(keyword => 
                searchWords.some(word => keyword.includes(word))
            );
            
            // Buscar coincidencias parciales en el título
            const partialTitleMatch = searchWords.some(word => 
                movie.title.toLowerCase().includes(word)
            );
            
            return titleMatch || keywordMatch || partialTitleMatch;
        });
    }
    
    if (filteredMovies.length > 0) {
        moviesData.innerHTML = filteredMovies.map(movie => `
            <a href="${movie.url}" target="_blank" class="movie-card">
                <img src="${movie.poster}" alt="${movie.title}" class="movie-poster" onerror="this.src='https://images.unsplash.com/photo-1489599809505-f2d4c3f70800?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80'">
                <div class="movie-info">
                    <h3 class="movie-title">${movie.title}</h3>
                    <p class="movie-overview">${movie.overview}</p>
                </div>
            </a>
        `).join('');
    } else {
        // Mostrar sugerencias cuando no se encuentra la película
        const suggestions = allMovies.slice(0, 4).map(movie => movie.title).join(', ');
        moviesData.innerHTML = `
            <div class="error">
                No se encontraron películas con ese nombre.<br><br>
                <strong>Sugerencias:</strong> ${suggestions}<br><br>
                Prueba con: "avengers", "spider", "batman", "mario", "john wick", "flash", "transformers", "mission impossible", "barbie"
            </div>
        `;
    }
});

// Mostrar todas las películas al cargar la página
setTimeout(() => {
    document.getElementById('movies-data').innerHTML = allMovies.map(movie => `
        <a href="${movie.url}" target="_blank" class="movie-card">
            <img src="${movie.poster}" alt="${movie.title}" class="movie-poster" onerror="this.src='https://images.unsplash.com/photo-1489599809505-f2d4c3f70800?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80'">
            <div class="movie-info">
                <h3 class="movie-title">${movie.title}</h3>
                <p class="movie-overview">${movie.overview}</p>
            </div>
        </a>
    `).join('');
}, 100);

// Clima - Diseño profesional mejorado
document.getElementById('search-weather').addEventListener('click', () => {
    const city = document.getElementById('city-input').value || 'Lima';
    const weatherData = document.getElementById('weather-data');
    
    // Simulación de datos de clima más realistas
    const citiesWeather = {
        'Lima': { temp: 22, desc: 'Parcialmente nublado', humidity: 78, wind: 15, pressure: 1013, icon: 'fa-cloud-sun' },
        'Buenos Aires': { temp: 18, desc: 'Despejado', humidity: 65, wind: 12, pressure: 1015, icon: 'fa-sun' },
        'Madrid': { temp: 14, desc: 'Lluvia ligera', humidity: 82, wind: 8, pressure: 1012, icon: 'fa-cloud-rain' },
        'Nueva York': { temp: 10, desc: 'Nublado', humidity: 75, wind: 20, pressure: 1010, icon: 'fa-cloud' },
        'Tokio': { temp: 16, desc: 'Soleado', humidity: 60, wind: 10, pressure: 1014, icon: 'fa-sun' },
        'Sídney': { temp: 25, desc: 'Caluroso', humidity: 55, wind: 18, pressure: 1011, icon: 'fa-temperature-high' }
    };
    
    const weatherInfo = citiesWeather[city] || {
        temp: Math.floor(Math.random() * 30) + 5,
        desc: 'Parcialmente nublado',
        humidity: Math.floor(Math.random() * 40) + 40,
        wind: Math.floor(Math.random() * 25) + 5,
        pressure: Math.floor(Math.random() * 20) + 1000,
        icon: 'fa-cloud-sun'
    };
    
    const currentDate = new Date().toLocaleDateString('es-ES', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    
    weatherData.innerHTML = `
        <div class="weather-card">
            <div class="weather-header">
                <div class="weather-city">${city}</div>
                <div class="weather-date">${currentDate}</div>
            </div>
            <div class="weather-main">
                <div class="weather-temp">${weatherInfo.temp}°C</div>
                <div class="weather-icon">
                    <i class="fas ${weatherInfo.icon}"></i>
                </div>
            </div>
            <div class="weather-desc">${weatherInfo.desc}</div>
            <div class="weather-details">
                <div class="weather-detail">
                    <i class="fas fa-tint"></i>
                    <span>Humedad: ${weatherInfo.humidity}%</span>
                </div>
                <div class="weather-detail">
                    <i class="fas fa-wind"></i>
                    <span>Viento: ${weatherInfo.wind} km/h</span>
                </div>
                <div class="weather-detail">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Presión: ${weatherInfo.pressure} hPa</span>
                </div>
                <div class="weather-detail">
                    <i class="fas fa-eye"></i>
                    <span>Visibilidad: 10 km</span>
                </div>
            </div>
        </div>
    `;
});

// Noticias - 12 noticias en total (6 originales + 6 nuevas)
const newsData = document.getElementById('news-data');
const news = [
    {
        title: "Nuevo avance en inteligencia artificial revoluciona la industria",
        category: "Tecnología",
        author: "María López",
        date: "Hace 2 horas",
        image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
        url: "https://www.technologyreview.com/"
    },
    {
        title: "Lanzamiento del nuevo smartphone con características innovadoras",
        category: "Móviles",
        author: "Carlos Rodríguez",
        date: "Hace 5 horas",
        image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
        url: "https://www.gsmarena.com/"
    },
    {
        title: "Mercado financiero muestra tendencia alcista esta semana",
        category: "Finanzas",
        author: "Ana Martínez",
        date: "Hace 1 día",
        image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
        url: "https://www.bloomberg.com/"
    },
    {
        title: "Descubrimiento científico podría cambiar la medicina moderna",
        category: "Ciencia",
        author: "Dr. Javier Ruiz",
        date: "Hace 1 día",
        image: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
        url: "https://www.nature.com/"
    },
    {
        title: "Nueva serie de streaming rompe récords de audiencia",
        category: "Entretenimiento",
        author: "Laura Gómez",
        date: "Hace 2 días",
        image: "https://images.unsplash.com/photo-1489599809505-f2d4c3f70800?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
        url: "https://www.netflix.com/"
    },
    {
        title: "Empresa de energía anuncia inversión millonaria en renovables",
        category: "Medio Ambiente",
        author: "Pedro Sánchez",
        date: "Hace 3 días",
        image: "https://images.unsplash.com/photo-1466611653911-95081537e5b7?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
        url: "https://www.greenpeace.org/"
    },
    // 6 NUEVAS NOTICIAS
    {
        title: "Inteligencia Artificial predice nuevos materiales revolucionarios",
        category: "Ciencia",
        author: "Dr. Elena Vargas",
        date: "Hace 4 horas",
        image: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
        url: "https://www.science.org/"
    },
    {
        title: "Nuevo protocolo de internet promete mayor velocidad y seguridad",
        category: "Tecnología",
        author: "Miguel Ángel Torres",
        date: "Hace 6 horas",
        image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
        url: "https://www.wired.com/"
    },
    {
        title: "Startup de biotecnología desarrolla tratamiento contra el cáncer",
        category: "Salud",
        author: "Dra. Carolina Méndez",
        date: "Hace 8 horas",
        image: "https://images.unsplash.com/photo-1559757175-0eb30cd8c063?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
        url: "https://www.who.int/"
    },
    {
        title: "Turismo espacial: Primera misión comercial a la estación lunar",
        category: "Espacio",
        author: "Roberto Jiménez",
        date: "Hace 12 horas",
        image: "https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
        url: "https://www.spacex.com/"
    },
    {
        title: "Deportes: Nuevo récord mundial en atletismo",
        category: "Deportes",
        author: "Juan Carlos Herrera",
        date: "Hace 1 día",
        image: "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
        url: "https://www.espn.com/"
    },
    {
        title: "Arte digital: Exposición de NFTs en museo tradicional",
        category: "Arte",
        author: "Sofía Ramírez",
        date: "Hace 2 días",
        image: "https://images.unsplash.com/photo-1541961017774-22349e4a1262?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
        url: "https://www.artsy.net/"
    }
];

newsData.innerHTML = news.map(item => `
    <a href="${item.url}" target="_blank" class="news-card">
        <img src="${item.image}" alt="${item.title}" class="news-image" onerror="this.src='https://images.unsplash.com/photo-1585829365295-ab7cd400c167?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80'">
        <div class="news-content">
            <span class="news-category">${item.category}</span>
            <h3 class="news-title">${item.title}</h3>
            <div class="news-meta">
                <span>Por ${item.author}</span>
                <span>${item.date}</span>
            </div>
        </div>
    </a>
`).join('');

// GitHub - Listado de desarrolladores con enlaces
const githubData = document.getElementById('github-data');
const developers = [
    {
        name: "Linus Torvalds",
        avatar: "https://avatars.githubusercontent.com/u/1024025?v=4",
        url: "https://github.com/torvalds"
    },
    {
        name: "Brendan Gregg",
        avatar: "https://avatars.githubusercontent.com/u/1101211?v=4",
        url: "https://github.com/brendangregg"
    },
    {
        name: "Guido van Rossum",
        avatar: "https://avatars.githubusercontent.com/u/2894642?v=4",
        url: "https://github.com/gvanrossum"
    },
    {
        name: "Addy Osmani",
        avatar: "https://avatars.githubusercontent.com/u/110953?v=4",
        url: "https://github.com/addyosmani"
    },
    {
        name: "Sarah Drasner",
        avatar: "https://avatars.githubusercontent.com/u/2281088?v=4",
        url: "https://github.com/sdras"
    },
    {
        name: "Wes Bos",
        avatar: "https://avatars.githubusercontent.com/u/176013?v=4",
        url: "https://github.com/wesbos"
    },
    {
        name: "Rachel Andrew",
        avatar: "https://avatars.githubusercontent.com/u/20056?v=4",
        url: "https://github.com/rachelandrew"
    },
    {
        name: "Dan Abramov",
        avatar: "https://avatars.githubusercontent.com/u/810438?v=4",
        url: "https://github.com/gaearon"
    },
    {
        name: "Taylor Otwell",
        avatar: "https://avatars.githubusercontent.com/u/463230?v=4",
        url: "https://github.com/taylorotwell"
    },
    {
        name: "Evan You",
        avatar: "https://avatars.githubusercontent.com/u/499550?v=4",
        url: "https://github.com/yyx990803"
    }
];

githubData.innerHTML = developers.map(dev => `
    <a href="${dev.url}" target="_blank" class="github-card">
        <img src="${dev.avatar}" alt="${dev.name}" class="github-avatar">
        <div class="github-name">${dev.name}</div>
    </a>
`).join('');

// Países - Listado de países con enlaces
const countriesData = document.getElementById('countries-data');

const countries = [
    { name: "Perú", capital: "Lima", flag: "https://flagcdn.com/w320/pe.png", url: "https://es.wikipedia.org/wiki/Per%C3%BA" },
    { name: "Argentina", capital: "Buenos Aires", flag: "https://flagcdn.com/w320/ar.png", url: "https://es.wikipedia.org/wiki/Argentina" },
    { name: "Brasil", capital: "Brasilia", flag: "https://flagcdn.com/w320/br.png", url: "https://es.wikipedia.org/wiki/Brasil" },
    { name: "Chile", capital: "Santiago", flag: "https://flagcdn.com/w320/cl.png", url: "https://es.wikipedia.org/wiki/Chile" },
    { name: "Colombia", capital: "Bogotá", flag: "https://flagcdn.com/w320/co.png", url: "https://es.wikipedia.org/wiki/Colombia" },
    { name: "México", capital: "Ciudad de México", flag: "https://flagcdn.com/w320/mx.png", url: "https://es.wikipedia.org/wiki/M%C3%A9xico" },
    { name: "España", capital: "Madrid", flag: "https://flagcdn.com/w320/es.png", url: "https://es.wikipedia.org/wiki/Espa%C3%B1a" },
    { name: "Estados Unidos", capital: "Washington D.C.", flag: "https://flagcdn.com/w320/us.png", url: "https://es.wikipedia.org/wiki/Estados_Unidos" },
    { name: "Francia", capital: "París", flag: "https://flagcdn.com/w320/fr.png", url: "https://es.wikipedia.org/wiki/Francia" },
    { name: "Alemania", capital: "Berlín", flag: "https://flagcdn.com/w320/de.png", url: "https://es.wikipedia.org/wiki/Alemania" },
    { name: "Italia", capital: "Roma", flag: "https://flagcdn.com/w320/it.png", url: "https://es.wikipedia.org/wiki/Italia" },
    { name: "Japón", capital: "Tokio", flag: "https://flagcdn.com/w320/jp.png", url: "https://es.wikipedia.org/wiki/Jap%C3%B3n" },
    { name: "Canadá", capital: "Ottawa", flag: "https://flagcdn.com/w320/ca.png", url: "https://es.wikipedia.org/wiki/Canad%C3%A1" },
    { name: "Australia", capital: "Canberra", flag: "https://flagcdn.com/w320/au.png", url: "https://es.wikipedia.org/wiki/Australia" },
    { name: "Reino Unido", capital: "Londres", flag: "https://flagcdn.com/w320/gb.png", url: "https://es.wikipedia.org/wiki/Reino_Unido" }
];

countriesData.innerHTML = countries.map(country => `
    <a href="${country.url}" target="_blank" class="country-card">
        <img src="${country.flag}" alt="${country.name}" class="country-flag">
        <div class="country-name">${country.name}</div>
        <div class="country-capital">${country.capital}</div>
    </a>
`).join('');

// Criptomonedas - Datos con diseño exacto solicitado y enlaces
const cryptoData = document.getElementById('crypto-data');
const cryptocurrencies = [
    {
        name: "Bitcoin",
        symbol: "BTC",
        price: 29450.25,
        change: 2.5,
        icon: "https://assets.coincap.io/assets/icons/btc@2x.png",
        url: "https://coinmarketcap.com/currencies/bitcoin/"
    },
    {
        name: "Ethereum",
        symbol: "ETH",
        price: 1850.75,
        change: 1.8,
        icon: "https://assets.coincap.io/assets/icons/eth@2x.png",
        url: "https://coinmarketcap.com/currencies/ethereum/"
    },
    {
        name: "Cardano",
        symbol: "ADA",
        price: 0.38,
        change: -0.5,
        icon: "https://assets.coincap.io/assets/icons/ada@2x.png",
        url: "https://coinmarketcap.com/currencies/cardano/"
    },
    {
        name: "Solana",
        symbol: "SOL",
        price: 42.15,
        change: 5.2,
        icon: "https://assets.coincap.io/assets/icons/sol@2x.png",
        url: "https://coinmarketcap.com/currencies/solana/"
    },
    {
        name: "Polkadot",
        symbol: "DOT",
        price: 6.75,
        change: -1.2,
        icon: "https://assets.coincap.io/assets/icons/dot@2x.png",
        url: "https://coinmarketcap.com/currencies/polkadot/"
    },
    {
        name: "Dogecoin",
        symbol: "DOGE",
        price: 0.082,
        change: 0.3,
        icon: "https://assets.coincap.io/assets/icons/doge@2x.png",
        url: "https://coinmarketcap.com/currencies/dogecoin/"
    },
    {
        name: "Chainlink",
        symbol: "LINK",
        price: 7.25,
        change: 1.1,
        icon: "https://assets.coincap.io/assets/icons/link@2x.png",
        url: "https://coinmarketcap.com/currencies/chainlink/"
    },
    {
        name: "Litecoin",
        symbol: "LTC",
        price: 85.40,
        change: -0.8,
        icon: "https://assets.coincap.io/assets/icons/ltc@2x.png",
        url: "https://coinmarketcap.com/currencies/litecoin/"
    }
];

cryptoData.innerHTML = cryptocurrencies.map(crypto => `
    <a href="${crypto.url}" target="_blank" class="crypto-card">
        <div class="crypto-icon">
            <img src="${crypto.icon}" alt="${crypto.name}" onerror="this.src='https://cryptologos.cc/logos/${crypto.name.toLowerCase()}-${crypto.symbol.toLowerCase()}-logo.png'">
        </div>
        <div class="crypto-info">
            <div class="crypto-name">${crypto.name}</div>
            <div class="crypto-symbol">${crypto.symbol}</div>
        </div>
        <div class="crypto-price">
            <div class="price">$${crypto.price.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
            <div class="price-change ${crypto.change >= 0 ? 'positive' : 'negative'}">
                <i class="fas fa-arrow-${crypto.change >= 0 ? 'up' : 'down'}"></i>
                ${crypto.change >= 0 ? '+' : ''}${crypto.change}%
            </div>
        </div>
    </a>
`).join('');

// Inicializar con datos de clima por defecto
setTimeout(() => {
    document.getElementById('city-input').value = 'Lima';
    document.getElementById('search-weather').click();
}, 100);