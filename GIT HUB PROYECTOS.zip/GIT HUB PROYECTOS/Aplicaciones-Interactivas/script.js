// Sistema de navegación entre secciones
function showSection(sectionId) {
    // Ocultar todas las secciones
    const sections = document.querySelectorAll('.app-section');
    sections.forEach(section => {
        section.classList.remove('active');
    });
    
    // Desactivar todos los botones
    const buttons = document.querySelectorAll('.nav-btn');
    buttons.forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Mostrar la sección seleccionada
    document.getElementById(sectionId).classList.add('active');
    
    // Activar el botón correspondiente
    event.target.classList.add('active');
}

// ==============================================
// APP 1: JUEGO ANIMADO - EL CHAVO DEL 8
// ==============================================

const dialogs = {
    char1: [
        "si listo para ganar si",
        "pipipipipipipipip",
        "pipipipipipipipip",
        "pipipipipipipipip",
        "¡Tengo una panza!",
        "pipipipipipipipip"
    ],
    char2: [
        "ay ya callate callate callate que me desesperas",
        "¿Y ahora quién podrá defenderme?",
        "Hola chavito vamos a jugar",
        "Hola chavito vamos a jugar",
        "ay ya callate callate que me desesperas"
    ],
    char3: [
        "mm a jajajajajajajajaj",
        "¡Bueno, pero no se enoje!",
        "mmm a jajajajajajajaja",
        "toma no te doy otra nomas por que",
        "toma no te doy otra nomas por que"
    ]
};

// Configuración de audios
const audioFiles = {
    chavo: [
        'audios/chavo1.mp3',
        'audios/chavo2.mp3',
        'audios/chavo3.mp3'
    ],
    kiko: [
        'audios/kiko1.mp3',
        'audios/kiko2.mp3',
        'audios/kiko3.mp3'
    ],
    quico: [
        'audios/don-ramon1.mp3',
        'audios/don-ramon2.mp3'
    ]
};

let currentAudio = null;

function animateCharacters() {
    const canvas = document.getElementById('game-canvas');
    const canvasWidth = canvas.offsetWidth - 120;
    const canvasHeight = canvas.offsetHeight - 140;
    
    const chars = document.querySelectorAll('.character');
    chars.forEach((char) => {
        const randomX = Math.random() * canvasWidth;
        const randomY = Math.random() * canvasHeight;
        char.style.left = randomX + 'px';
        char.style.top = randomY + 'px';
        
        const img = char.querySelector('.character-img');
        img.style.transform = `scale(${1 + Math.random() * 0.3}) rotate(${Math.random() * 20 - 10}deg)`;
        
        setTimeout(() => {
            img.style.transform = 'scale(1) rotate(0deg)';
        }, 500);
    });
}

function makeThemTalk() {
    ['char1', 'char2', 'char3'].forEach((charId, index) => {
        const char = document.getElementById(charId);
        const dialog = document.getElementById(`dialog${index + 1}`);
        const messages = dialogs[charId];
        const randomMessage = messages[Math.floor(Math.random() * messages.length)];
        
        dialog.textContent = randomMessage;
        dialog.style.display = 'block';
        dialog.style.left = char.offsetLeft + 'px';
        dialog.style.top = (char.offsetTop - 80) + 'px';
        
        setTimeout(() => {
            dialog.style.display = 'none';
        }, 3500);
    });
}

function playRandomAudio() {
    const characters = ['chavo', 'kiko', 'quico'];
    const randomChar = characters[Math.floor(Math.random() * characters.length)];
    const audios = audioFiles[randomChar];
    const randomAudio = audios[Math.floor(Math.random() * audios.length)];
    
    playAudio(randomAudio);
}

function playAudio(audioSrc) {
    // Detener audio anterior si existe
    if (currentAudio) {
        currentAudio.pause();
        currentAudio.currentTime = 0;
    }
    
    currentAudio = new Audio(audioSrc);
    currentAudio.play().catch(error => {
        console.log('Error al reproducir audio:', error);
        alert('⚠️ No se pudo reproducir el audio. Asegúrate de que los archivos de audio estén en la carpeta "audios"');
    });
}

function resetGame() {
    document.getElementById('char1').style = 'left: 80px; top: 200px;';
    document.getElementById('char2').style = 'left: 300px; top: 200px;';
    document.getElementById('char3').style = 'left: 520px; top: 200px;';
    document.querySelectorAll('.dialog-box').forEach(d => d.style.display = 'none');
    
    // Detener audio si está sonando
    if (currentAudio) {
        currentAudio.pause();
        currentAudio.currentTime = 0;
    }
}

// Añadir eventos click a los personajes
document.addEventListener('DOMContentLoaded', function() {
    const characters = document.querySelectorAll('.character');
    
    characters.forEach((char, index) => {
        char.addEventListener('click', function() {
            const img = this.querySelector('.character-img');
            img.style.transform = 'scale(1.3) rotate(360deg)';
            
            setTimeout(() => {
                img.style.transform = 'scale(1) rotate(0deg)';
            }, 600);
            
            // Reproducir audio del personaje
            const charName = this.getAttribute('data-name');
            if (audioFiles[charName]) {
                const audios = audioFiles[charName];
                const randomAudio = audios[Math.floor(Math.random() * audios.length)];
                playAudio(randomAudio);
            }
            
            // Mostrar diálogo
            const dialogId = `dialog${index + 1}`;
            const dialog = document.getElementById(dialogId);
            const charId = this.id;
            const messages = dialogs[charId];
            const randomMessage = messages[Math.floor(Math.random() * messages.length)];
            
            dialog.textContent = randomMessage;
            dialog.style.display = 'block';
            dialog.style.left = this.offsetLeft + 'px';
            dialog.style.top = (this.offsetTop - 80) + 'px';
            
            setTimeout(() => {
                dialog.style.display = 'none';
            }, 3000);
        });
    });
});

// ==============================================
// APP 2: CHAT BOT
// ==============================================

const responses = {
    'hola': ['¡Hola! ¿Cómo estás?', '¡Hey! ¿En qué puedo ayudarte?', '¡Hola amigo! 👋', '¡Saludos! ¿Qué tal tu día?'],
    'como estas': ['¡Muy bien! Gracias por preguntar 😊', 'Excelente, ¿y tú?', 'De maravilla, listo para chatear', '¡Genial! ¿Cómo te va a ti?'],
    'adios': ['¡Hasta luego! 👋', 'Nos vemos pronto', '¡Que tengas un gran día!', '¡Chao! Vuelve pronto'],
    'gracias': ['¡De nada! 😊', 'Para eso estoy aquí', 'Un placer ayudarte', '¡Siempre a tu servicio!'],
    'que haces': ['Estoy aquí para charlar contigo', 'Esperando tus mensajes', 'Listo para ayudarte', 'Conversando contigo 😄'],
    'ayuda': ['Puedes preguntarme sobre el clima, pedirme un chiste, o simplemente charlar', 'Estoy aquí para conversar contigo', 'Pregunta lo que quieras'],
    'chiste': [
        '¿Por qué los pájaros no usan Facebook? Porque ya tienen Twitter 🐦',
        '¿Qué le dice un gusano a otro? Voy a dar una vuelta a la manzana 🍎',
        '¿Cómo se llama el campeón de buceo japonés? Tokofondo Masvale',
        '¿Qué hace una abeja en el gimnasio? ¡Zum-ba!'
    ],
    'nombre': ['Soy ChatBot, tu asistente virtual', 'Me llamo ChatBot, encantado', 'Soy tu amigo ChatBot 🤖'],
    'clima': ['Parece un día perfecto para programar ☀️', 'El clima está ideal hoy', '¡Hace un tiempo espectacular!'],
    'hora': [`Son las ${new Date().toLocaleTimeString('es-ES')} ⏰`],
    'default': ['Interesante... cuéntame más', 'Entiendo, ¿algo más?', 'Eso es genial 👍', '¿En serio? Dime más', 'Cuéntame más sobre eso']
};

function sendMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();
    
    if (message === '') return;
    
    const messagesContainer = document.getElementById('chat-messages');
    
    const userMsg = document.createElement('div');
    userMsg.className = 'message user';
    userMsg.textContent = message;
    messagesContainer.appendChild(userMsg);
    
    input.value = '';
    
    setTimeout(() => {
        const botResponse = getBotResponse(message.toLowerCase());
        const botMsg = document.createElement('div');
        botMsg.className = 'message bot';
        botMsg.textContent = botResponse;
        messagesContainer.appendChild(botMsg);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }, 800);
    
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function getBotResponse(message) {
    for (let key in responses) {
        if (message.includes(key)) {
            const possibleResponses = responses[key];
            return possibleResponses[Math.floor(Math.random() * possibleResponses.length)];
        }
    }
    return responses['default'][Math.floor(Math.random() * responses['default'].length)];
}

// ==============================================
// APP 3: EDITOR DE TEXTO
// ==============================================

let savedTexts = {};

function saveText() {
    const text = document.getElementById('text-editor').value;
    if (text.trim() === '') {
        alert('⚠️ No hay texto para guardar');
        return;
    }
    const timestamp = new Date().toLocaleString();
    savedTexts[timestamp] = text;
    alert('✅ Texto guardado exitosamente\nFecha: ' + timestamp);
}

function loadText() {
    if (Object.keys(savedTexts).length === 0) {
        alert('❌ No hay textos guardados');
        return;
    }
    
    let list = 'Selecciona un texto guardado:\n\n';
    let keys = Object.keys(savedTexts);
    keys.forEach((key, index) => {
        list += `${index + 1}. ${key}\n`;
    });
    
    const selection = prompt(list + '\nIngresa el número:');
    if (selection && selection > 0 && selection <= keys.length) {
        document.getElementById('text-editor').value = savedTexts[keys[selection - 1]];
        alert('✅ Texto cargado');
    }
}

function clearText() {
    if (confirm('¿Estás seguro de borrar todo el contenido?')) {
        document.getElementById('text-editor').value = '';
        alert('✅ Contenido borrado');
    }
}

function downloadText() {
    const text = document.getElementById('text-editor').value;
    if (text.trim() === '') {
        alert('❌ No hay texto para descargar');
        return;
    }
    
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'mi-documento.txt';
    a.click();
    URL.revokeObjectURL(url);
    alert('✅ Archivo descargado exitosamente');
}

// ==============================================
// APP 4: SISTEMA DE VOTACIÓN
// ==============================================

let votes = {
    'JavaScript': 0,
    'Python': 0,
    'Java': 0,
    'C++': 0
};

function submitVote() {
    const selected = document.querySelector('input[name="vote"]:checked');
    
    if (!selected) {
        alert('⚠️ Por favor selecciona una opción');
        return;
    }
    
    votes[selected.value]++;
    
    document.querySelector('.poll-options').style.display = 'none';
    document.querySelector('.poll-submit').style.display = 'none';
    document.getElementById('poll-results').style.display = 'block';
    
    showResults();
}

function showResults() {
    const total = Object.values(votes).reduce((a, b) => a + b, 0);
    const container = document.getElementById('results-container');
    container.innerHTML = '';
    
    for (let option in votes) {
        const count = votes[option];
        const percentage = total > 0 ? ((count / total) * 100).toFixed(1) : 0;
        
        const resultDiv = document.createElement('div');
        resultDiv.className = 'result-bar';
        resultDiv.innerHTML = `
            <div class="result-label">
                <span>${option}</span>
                <span>${count} votos (${percentage}%)</span>
            </div>
            <div class="bar-container">
                <div class="bar-fill" style="width: ${percentage}%">${percentage}%</div>
            </div>
        `;
        
        container.appendChild(resultDiv);
    }
}