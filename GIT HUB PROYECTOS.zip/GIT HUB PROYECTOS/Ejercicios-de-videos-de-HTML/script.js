// Para Ejercicio 3: Cambiar mensaje según la hora
function actualizarMensaje() {
    const hora = new Date().getHours();
    const mensaje = document.getElementById('mensaje-hora');
    if (hora < 12) {
        mensaje.textContent = "¡Buenos días! ¡A trabajar!";
    } else if (hora < 18) {
        mensaje.textContent = "¡Buenas tardes! ¡Sigue adelante!";
    } else {
        mensaje.textContent = "¡Buenas noches! ¡Descansa bien!";
    }
}
actualizarMensaje();
setInterval(actualizarMensaje, 60000); // Actualiza cada minuto

// Para Ejercicio 5: Controles personalizados
const video = document.getElementById('video-personalizado');
function playVideo() {
    video.play();
}
function pauseVideo() {
    video.pause();
}
video.addEventListener('timeupdate', function() {
    const minutos = Math.floor(video.currentTime / 60);
    const segundos = Math.floor(video.currentTime % 60);
    document.getElementById('tiempo').textContent = `Tiempo: ${minutos}:${segundos.toString().padStart(2, '0')}`;
});